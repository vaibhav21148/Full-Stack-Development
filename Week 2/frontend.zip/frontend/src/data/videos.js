const videos = [
  {
    id: 1,
    title: "React Hooks Explained",
    channel: "CodeWithYou",
    views: "1.2M",
    time: "2 days ago",
    thumbnail: "https://via.placeholder.com/300x170",
  },
  {
    id: 2,
    title: "Flexbox in 10 minutes",
    channel: "CSSNinjas",
    views: "860K",
    time: "1 week ago",
    thumbnail: "https://via.placeholder.com/300x170",
  },
  // Add more!
];

export default videos;